#' DesignLibrary: A package for creating designs
#'
#' 
#' 
#' @docType package
#' 
#' @name DesignLibrary
#' 
#' 


utils::globalVariables(c("N", "u_0", "Y_Z_1", "Y_Z_0", "blocks", "clusters"))


