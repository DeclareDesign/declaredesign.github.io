## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(ggplot2)
library(knitr)

## ----include=FALSE, warning=FALSE, message=FALSE-------------------------
regression_discontinuity_design <- regression_discontinuity_designer()
pro_con_colors <- c("#C67800", "#205C8A")
dd_theme <-
  function() {
    theme_bw() +
      theme(
        axis.ticks = element_blank(),
        axis.line = element_blank(),
        panel.border = element_blank(),
        panel.grid.major = element_line(color = '#eeeeee'),
        strip.background = element_blank(),
        legend.position = "bottom",
        text = element_text(family = "Palatino"))
  }

control <- function(X) {
  as.vector(poly(X, 4, raw = T) %*% c(.7, -.8, .5, 1))}
treatment <- function(X) {
  as.vector(poly(X, 4, raw = T) %*% c(0, -1.5, .5, .8)) + .15}
mock_data <- draw_data(regression_discontinuity_design)
X <- seq(-.5,.5,.005)
treatment_frame <- data.frame(
  X = X,
  Y = treatment(X),
  observed = ifelse(X > 0,"a","b"),
  Z = 1
  )
control_frame <- data.frame(
  X = X,
  Y = control(X),
  observed = ifelse(X <= 0,"a","b"),
  Z = 0
  )
plot_frame <- rbind(treatment_frame, control_frame)

## ----echo=FALSE,warning=FALSE, message=FALSE-----------------------------
ggplot(plot_frame,aes(x = X, y = Y, color = as.factor(Z))) + 
  geom_line(aes(linetype = observed)) +
  geom_point(data = mock_data, alpha = .2, size = .5) +
  scale_linetype_discrete(name = "", labels = c("Observable","Unobservable")) +
  scale_color_manual(name = "", labels = c("Untreated","Treated"),values = pro_con_colors) +
  geom_vline(xintercept = 0, size = .05) +
  xlab("Running Variable") + 
  geom_segment(aes(x = 0,xend = 0, y = control(0),yend = treatment(0)),color = "black") +
  dd_theme()

## ---- eval = TRUE, code = get_design_code(regression_discontinuity_designer())----
N <- 1000
tau <- 0.15
cutoff <- 0.5
bandwidth <- 0.5
poly_order <- 4

# M: Model
control <- function(X) {
  as.vector(poly(X, 4, raw = T) %*% c(.7, -.8, .5, 1))}
treatment <- function(X) {
  as.vector(poly(X, 4, raw = T) %*% c(0, -1.5, .5, .8)) + tau}
population <- declare_population(
  N = N,
  X = runif(N,0,1) - cutoff,
  noise = rnorm(N,0,.1),
  Z = 1 * (X > 0))
potentials <- declare_potential_outcomes(
  Y_Z_0 = control(X) + noise,
  Y_Z_1 = treatment(X) + noise)
reveal_Y <- declare_reveal(Y)

# I: Inquiry
estimand <- declare_estimand(LATE = treatment(0) - control(0))

# D: Data Strategy
sampling <- declare_sampling(handler = function(data){
  subset(data,(X > 0 - abs(bandwidth)) & X < 0 + abs(bandwidth))})

# A: Answer Strategy 
estimator <- declare_estimator(
  formula = Y ~ poly(X, poly_order) * Z,
  model = lm_robust,
  term = "Z",
  estimand = estimand)

# Design
regression_discontinuity_design <- 
  population + potentials + estimand + reveal_Y + sampling + estimator

## ------------------------------------------------------------------------
diagnosis <- diagnose_design(regression_discontinuity_design)

## ---- echo=FALSE---------------------------------------------------------
kable(reshape_diagnosis(diagnosis)[,-c(1:2)], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  regression_discontinuity_design <- regression_discontinuity_designer(N = 300,
#                                                          tau = .2,
#                                                          cutoff = .4,
#                                                          bandwidth = .01,
#                                                          poly_order = .15)

## ---- eval=FALSE---------------------------------------------------------
#  ??regression_discontinuity_designer

