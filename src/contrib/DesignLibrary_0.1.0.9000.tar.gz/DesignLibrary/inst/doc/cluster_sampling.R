## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(ggplot2)
library(knitr)

## ----eval = TRUE, code = get_design_code(cluster_sampling_designer(n_clusters = 30, n_i_in_cluster = 20, icc = 0.402))----
N_blocks <- 1
N_clusters_in_block <- 1000
N_i_in_cluster <- 50
n_clusters_in_block <- 30
n_i_in_cluster <- 20
icc <- 0.402

# M: Model
fixed_pop <-
  declare_population(
    block = add_level(N = N_blocks),
    cluster = add_level(N = N_clusters_in_block),
    subject = add_level(N = N_i_in_cluster,
                        latent = draw_normal_icc(mean = 0, N = N, clusters = cluster, ICC = icc),
                        Y = draw_ordered(x = latent, breaks = qnorm(seq(0, 1, length.out = 8)))
    )
  )()

population <- declare_population(data = fixed_pop)

# I: Inquiry
estimand <- declare_estimand(mean(Y), label = "Ybar")

# D: Data Strategy
stage_1_sampling <- declare_sampling(strata = block, 
                                     clusters = cluster, n = n_clusters_in_block, 
                                     sampling_variable = "Cluster_Sampling_Prob")
stage_2_sampling <- declare_sampling(strata = cluster,   n = n_i_in_cluster, 
                                     sampling_variable = "Within_Cluster_Sampling_Prob")

# A: Answer Strategy
clustered_ses <- declare_estimator(Y ~ 1,
                                   model = lm_robust,
                                   clusters = cluster,
                                   estimand = estimand,
                                   label = "Clustered Standard Errors")


# Design
cluster_sampling_design <- population + estimand +
  stage_1_sampling + stage_2_sampling + clustered_ses

## ------------------------------------------------------------------------
diagnosis <- diagnose_design(cluster_sampling_design)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[, -c(1:2, 4:6)], digits = 2)

## ----plot setup, echo=TRUE, warning=FALSE--------------------------------

new_design <- cluster_sampling_design + declare_estimator(Y ~ 1,
                                        model = lm_robust,
                                        estimand = estimand,
                                        label = "Naive Standard Errors")
diagnosis <- diagnose_design(new_design)

## ----plot, echo=FALSE, warning=FALSE-------------------------------------


sims <- diagnosis$simulations

dd_theme <-
  function() {
    theme_bw() +
      theme(
        axis.ticks = element_blank(),
        axis.line = element_blank(),
        panel.border = element_blank(),
        panel.grid.major = element_line(color = '#eeeeee'),
        strip.background = element_blank(),
        legend.position = "bottom"
        # text = element_text(family = "Palatino")
        )
  }

  sims$covered <- factor(1 + (sims$conf.low < sims$estimand & sims$estimand < sims$conf.high), 1:2, labels = c("Estimand not covered by confidence interval", "Estimand covered by confidence interval"))
  sims$estimator_label <- as.factor(sims$estimator_label)
  sims$estimator_label <- factor(sims$estimator_label, levels = rev(levels(sims$estimator_label)))
  sims$estimand_label  <- as.factor(sims$estimand_label)
  
  ggplot(sims, aes(x=estimate)) +
    geom_errorbar(aes(ymin=conf.low, ymax=conf.high, color=covered), alpha=.4) +
    geom_hline(aes(yintercept=mean(estimand))) +
    geom_text(aes(x=x, y=y, label=label),
              data=function(df){
                data.frame(x=min(df$estimate),
                           y=mean(df$estimand),
                           label=sprintf('  Avg Estimand:\n  %4.3f', mean(df$estimand)),
                           stringsAsFactors = FALSE)
              }, hjust='left') +
    facet_wrap(estimand_label~estimator_label) +
    ylab("Estimate") +
    scale_x_continuous(labels=NULL, breaks = NULL, name='') +
    scale_color_discrete(drop=FALSE, name = '') +
    coord_flip() +
    dd_theme()
  

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  my_cluster_sampling_design <- cluster_sampling_designer(n_clusters = 40,
#                                                          n_i_in_cluster = 20,
#                                                          icc = .2,
#                                                          N_clusters = 1000,
#                                                          N_i_in_cluster = 50)

## ---- eval=FALSE---------------------------------------------------------
#  ??cluster_sampling_designer

