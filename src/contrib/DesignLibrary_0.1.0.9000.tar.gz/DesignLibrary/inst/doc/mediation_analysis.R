## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(DesignLibrary)
library(knitr)

## ---- code = get_design_code( mediation_analysis_designer()), eval=TRUE----
N <- 200
a <- 1
b <- 0.4
c <- 0
d <- 0.5
rho <- 0

# M: Model
population <- declare_population(
  N = N, 
  e1 = rnorm(N),
  e2 = rnorm(n = N, mean = rho * e1, sd = 1 - rho^2)
)
potentials_M <- declare_potential_outcomes(M ~ 1*(a * Z + e1 > 0))
potentials_Y <- declare_potential_outcomes(Y ~ d * Z + b * M + c * M * Z + e2,
                                           conditions = list(M = 0:1, Z = 0:1))
pots_Y_nat_0 <- declare_potential_outcomes(
  Y_nat0_Z_0 =     b * M_Z_0             + e2,
  Y_nat0_Z_1 = d + b * M_Z_0 + c * M_Z_0 + e2)
pots_Y_nat_1 <- declare_potential_outcomes(
  Y_nat1_Z_0 =     b * M_Z_1             + e2,
  Y_nat1_Z_1 = d + b * M_Z_1 + c * M_Z_1 + e2)

# I: Inquiry
estimands <- declare_estimands(
  FirstStage          = mean(M_Z_1      - M_Z_0), 
  Indirect_0          = mean(Y_M_1_Z_0  - Y_M_0_Z_0),
  Indirect_1          = mean(Y_M_1_Z_1  - Y_M_0_Z_1),
  Controlled_Direct_0 = mean(Y_M_0_Z_1  - Y_M_0_Z_0),
  Controlled_Direct_1 = mean(Y_M_1_Z_1  - Y_M_1_Z_0),
  Natural_Direct_0    = mean(Y_nat0_Z_1 - Y_nat0_Z_0),
  Natural_Direct_1    = mean(Y_nat1_Z_1 - Y_nat1_Z_0)
)

# D: Data strategy 
assignment   <- declare_assignment()
reveal_M     <- declare_reveal(M, Z)
reveal_Y     <- declare_reveal(Y, assignment_variable = c("M","Z"))
reveal_nat0  <- declare_reveal(Y_nat0)
reveal_nat1  <- declare_reveal(Y_nat1)
manipulation <- declare_step(Not_M = 1-M, handler = fabricate)

# A: Answer Strategy
mediator_regression <- declare_estimator(
  M ~ Z,
  model = lm_robust,
  estimand = "FirstStage",
  label = "Stage 1")
stage2_1 <- declare_estimator(
  Y ~ Z * M,
  model = lm_robust,
  term = c("M"),
  estimand = c("Indirect_0"),
  label = "Stage 2"
)


stage2_2 <- declare_estimator(
  Y ~ Z * M,
  model = lm_robust,
  term = c("Z"),
  estimand = c("Controlled_Direct_0", "Natural_Direct_0"),
  label = "Direct_0"
)

stage2_3 <- declare_estimator(
  Y ~ Z * Not_M,
  model = lm_robust,
  term = c("Z"),
  estimand = c("Controlled_Direct_1", "Natural_Direct_1"),
  label = "Direct_1"
)

# Design
mediation_analysis_design <- population + 
  potentials_M + potentials_Y + pots_Y_nat_0 + pots_Y_nat_1 +
  estimands + assignment + 
  reveal_M + reveal_Y + reveal_nat0 + reveal_nat1 + manipulation +
  mediator_regression + stage2_1 +  stage2_2 + stage2_3

## ----eval = TRUE---------------------------------------------------------
designs <- expand_design(mediation_analysis_designer, rho = c(0,.5))
diagnosis <- diagnose_design(designs)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[,-1], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  mediation_analysis_design <- mediation_analysis_designer(
#    N = 500, a = .2, b = .4, d = .2, rho = .15)

## ---- eval=FALSE---------------------------------------------------------
#  ??mediation_analysis_designer

