## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(knitr)

## ---- code = get_design_code(simple_two_arm_designer()), eval=TRUE-------
N  <-  100
prob  <-  0.5
control_mean  <-  0
control_sd  <-  1
treatment_mean  <-  1
treatment_sd  <-  1
rho  <-  1

# M: Model
population <- declare_population(
  N = N,
  u_0 = rnorm(N),
  u_1 = rnorm(n = N, mean = rho * u_0, sd = sqrt(1 - rho^2)))

potentials <- declare_potential_outcomes(
  Y ~ (1-Z) * (u_0*control_sd + control_mean) + 
      Z     * (u_1*treatment_sd + treatment_mean))

# I: Inquiry
estimand <- declare_estimand(ATE = mean(Y_Z_1 - Y_Z_0))

# D: Data Strategy
assignment <- declare_assignment(prob = prob)

# A: Answer Strategy
estimator <- declare_estimator(Y ~ Z, estimand = estimand)
reveal_Y    <- declare_reveal()

# Design
simple_two_arm_design <- population + potentials + estimand + assignment + reveal_Y + estimator

## ------------------------------------------------------------------------
diagnosis <- diagnose_design(simple_two_arm_design)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[,-c(1,2,3,5)], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  simple_two_arm_design <- simple_two_arm_designer(N = 500, prob = .5, ate = .4)

## ---- eval=FALSE---------------------------------------------------------
#  ??simple_two_arm_designer

