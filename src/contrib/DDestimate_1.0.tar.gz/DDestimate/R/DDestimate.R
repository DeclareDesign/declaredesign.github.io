#' DDestimate package
#'
#' Some stuff about what this package is
#'
#' @docType package
#' @useDynLib DDestimate
#' @importFrom Rcpp evalCpp
#' @importFrom stats sd var model.matrix.default pt qt var weighted.mean
#' @name DDestimate
NULL


