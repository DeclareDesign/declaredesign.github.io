library(testthat)
library(DDestimate)

test_check("DDestimate")
