library(testthat)
library(fabricatr)

suppressWarnings(RNGversion("3.5.0"))

test_check("fabricatr")
