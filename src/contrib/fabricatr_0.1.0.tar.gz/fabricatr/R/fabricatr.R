#' fabricatr package
#'
#' Some stuff about what this package is
#'
#' @docType package
#' @importFrom stats median rbinom sd
#' @name fabricatr
NULL
