## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(knitr)

## ---- code = get_design_code(multi_arm_designer( means = c(0.5, 1, 2))), eval=TRUE----
N  <-  30
means  <-  c(0.5, 1, 2)
sds  <-  c(1, 1, 1)

# M: Model
population <- declare_population(N = N, u_1 = rnorm(N, 0, sds[1L]), u_2 = rnorm(N, 
    0, sds[2L]), u_3 = rnorm(N, 0, sds[3L]))

potentials <- declare_potential_outcomes(formula = Y ~ (means[1] + u_1) * (Z == 
    "1") + (means[2] + u_2) * (Z == "2") + (means[3] + u_3) * 
    (Z == "3"), conditions = c("1", "2", "3"), assignment_variables = Z)

# I: Inquiry
estimand  <- declare_estimands(ate_Y_Z_1_Y_Z_2 = mean(Y_Z_1 - Y_Z_2), ate_Y_Z_1_Y_Z_3 = mean(Y_Z_1 - 
    Y_Z_3), ate_Y_Z_2_Y_Z_3 = mean(Y_Z_2 - Y_Z_3))

# D: Data Strategy
assignment <- declare_assignment(num_arms = 3, conditions = c("1", "2", "3"
), assignment_variable = Z)

reveal_Y <-  declare_reveal(assignment_variables = Z)

# A: Answer Strategy
estimator <- declare_estimator(handler = function(data) {
    estimates <- rbind.data.frame(ate_Y_Z_1_Y_Z_2 = difference_in_means(formula = Y ~ 
        Z, data = data, condition1 = "2", condition2 = "1"), 
        ate_Y_Z_1_Y_Z_3 = difference_in_means(formula = Y ~ Z, 
            data = data, condition1 = "3", condition2 = "1"), 
        ate_Y_Z_2_Y_Z_3 = difference_in_means(formula = Y ~ Z, 
            data = data, condition1 = "3", condition2 = "2"))
    estimates$estimator_label <- "DIM"
    estimates$estimand_label <- rownames(estimates)
    estimates$estimate <- estimates$coefficients
    estimates$term <- NULL
    return(estimates)
})

# Design
multi_arm_design <-
  population + potentials + assignment + reveal_Y + estimand +  estimator


## ------------------------------------------------------------------------
diagnosis <- diagnose_design(multi_arm_design)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[,-c(1,12)], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  my_multi_arm_design <- multi_arm_designer(N = 80, m_arms = 4, means = c(-0.2, 0.2, 0.1, 0))

## ---- eval=FALSE---------------------------------------------------------
#  ??multi_arm_designer

