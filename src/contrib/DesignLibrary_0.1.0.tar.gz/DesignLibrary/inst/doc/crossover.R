## ----MIDA, echo = FALSE,include = FALSE----------------------------------
set.seed(1234)
library(DesignLibrary)
library(ggplot2)
library(systemfit)
library(knitr)

## ------------------------------------------------------------------------
library(systemfit)
SUR <- declare_estimator(
	handler = function(data){
		sur_fit <- systemfit(
			formula = list(YA ~ A, YB ~ B),
			method = "SUR",
			data = data)
		SUR_summ <- summary(sur_fit)$coefficients["eq1_A",]
		data.frame(
			term = "A",
			estimate = SUR_summ["Estimate"],
			std.error = SUR_summ["Std. Error"],
			p.value = SUR_summ["Pr(>|t|)"],
			conf.low = SUR_summ["Estimate"] - 1.96 * SUR_summ["Std. Error"],
			conf.high = SUR_summ["Estimate"] + 1.96 * SUR_summ["Std. Error"],
			estimand_label = "a",
			estimator_label = "SUR")})

## ---- code = get_design_code(crossover_designer(N = 120, a = .5, b = .5, crossover = .2, rho = .6)), eval=TRUE----
N <- 120
a <- 0.5
b <- 0.5
crossover <- 0.2
rho <- 0.6

# M: Model
population <- declare_population(
  N = N, 
  u_a = rnorm(N),
  u_b = rnorm(n = N, mean = rho * u_a, sd = sqrt(1 - rho^2))
)
potentials_A <- declare_potential_outcomes(
  YA ~ u_a + a*A + B* crossover * (b + u_b), conditions = list(A = 0:1, B = 0:1)
)
potentials_B <- declare_potential_outcomes(
  YB ~ u_b + b*B + A* crossover * (a + u_a), conditions = list(A = 0:1, B = 0:1)
)

# I: Inquiry
estimand <- declare_estimand(a = mean(YA_A_1_B_0 - YA_A_0_B_0))

# D: Data Strategy
assignment_A <- declare_assignment(assignment_variable = "A")
assignment_B <- declare_assignment(assignment_variable = "B", blocks = A)
reveal_YA    <- declare_reveal(YA, assignment_variables = c("A", "B")) 
reveal_YB    <- declare_reveal(YB, assignment_variables = c("A", "B")) 


# A: Answer Strategy
estimator_dir <- declare_estimator(YA ~ A,
                                   model = lm_robust,
                                   estimand = estimand,
                                   label = "Direct estimator")
estimator_sat <- declare_estimator(YA ~ A,
                                   model = lm_lin,
                                   covariates = ~B,
                                   estimand = estimand,
                                   label = "Saturated estimator")

# Design
crossover_design <- population + potentials_A + potentials_B +
  estimand + assignment_A + assignment_B + reveal_YA  + reveal_YB +
  estimator_dir + estimator_sat 

## ------------------------------------------------------------------------
crossover_design <- crossover_design + SUR
diagnosis <- diagnose_design(crossover_design)

## ----echo = FALSE--------------------------------------------------------
kable(reshape_diagnosis(diagnosis)[-c(1,2,4)], digits = 2,row.names = F)
# kable(reshape_diagnosis(diagnosis)[c(1,4,2,5,3,6), -c(1:2, 4:5)], digits = 2,row.names = F)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  my_crossover_design <- crossover_designer(N = 300,
#                                            a = .2,
#                                            b = .4,
#                                            crossover = .15)

## ---- eval=FALSE---------------------------------------------------------
#  ??crossover_designer

