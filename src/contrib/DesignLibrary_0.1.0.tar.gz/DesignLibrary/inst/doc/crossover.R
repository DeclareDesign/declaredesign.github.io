## ----MIDA, echo = FALSE,include = FALSE----------------------------------
set.seed(1234)
library(DesignLibrary)
library(ggplot2)
library(systemfit)
library(knitr)

## ------------------------------------------------------------------------
library(systemfit)
SUR <- declare_estimator(
	handler = function(data){
		sur_fit <- systemfit(
			formula = list(YA ~ A, YB ~ B),
			method = "SUR",
			data = data)
		SUR_summ <- summary(sur_fit)$coefficients["eq1_A",]
		data.frame(
			term = "A",
			estimate = SUR_summ["Estimate"],
			std.error = SUR_summ["Std. Error"],
			p.value = SUR_summ["Pr(>|t|)"],
			conf.low = SUR_summ["Estimate"] - 1.96 * SUR_summ["Std. Error"],
			conf.high = SUR_summ["Estimate"] + 1.96 * SUR_summ["Std. Error"],
			estimand_label = "a",
			estimator_label = "SUR")})

## ---- code = get_design_code(crossover_designer(N = 120, a = .5, b = .5, crossover = .2, rho = .6)), eval=TRUE----
N <- 120
a <- 0.5
b <- 0.5
crossover <- 0.2
rho <- 0.6

population <- declare_population(
  N = N, 
  u_a = rnorm(N),
  u_b = rnorm(n = N, mean = rho * u_a, sd = sqrt(1 - rho^2))
)
potential_outcomes_A <- declare_potential_outcomes(
  YA_Z_T1 = u_a,
  YA_Z_T2 = a + u_a,
  YA_Z_T3 = u_a + crossover * (b + u_b),
  YA_Z_T4 = a + u_a + crossover * (b + u_b)
)
potential_outcomes_B <- declare_potential_outcomes(
  YB_Z_T1 = u_b,
  YB_Z_T2 = u_b + crossover * (a + u_a),
  YB_Z_T3 = b + u_b,
  YB_Z_T4 = b + u_b + crossover * (a + u_a)
)
estimand <- declare_estimand(a = mean(YA_Z_T2 - YA_Z_T1))
assignment <- declare_assignment(num_arms = 4)
get_AB <- declare_step(
  A = as.numeric(Z %in% c("T2", "T4")),
  B = as.numeric(Z %in% c("T3", "T4")),
  handler = fabricate)
reveal_YA <- declare_reveal(YA, Z) 
reveal_YB <-   declare_reveal(YB, Z) 
estimator_direct <- declare_estimator(YA ~ A,
                                      model = lm_robust,
                                      term = "A",
                                      estimand = estimand,
                                      label = "Direct estimator")
estimator_sat <- declare_estimator(YA ~ A + B,
                                   model = lm_robust,
                                   term = "A",
                                   estimand = estimand,
                                   label = "Saturated estimator")
crossover_design <- 
  population +
  potential_outcomes_A +
  potential_outcomes_B +
  estimand +
  assignment +
  get_AB +
  reveal_YA + 
  reveal_YB +
  estimator_direct + 
  estimator_sat 

## ------------------------------------------------------------------------
crossover_design <- crossover_design + SUR
diagnosis <- diagnose_design(crossover_design)

## ----echo = FALSE--------------------------------------------------------
kable(reshape_diagnosis(diagnosis)[-c(1,2,4)], digits = 2,row.names = F)
# kable(reshape_diagnosis(diagnosis)[c(1,4,2,5,3,6), -c(1:2, 4:5)], digits = 2,row.names = F)

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github("DeclareDesign/DesignLibrary", keep_source = TRUE)
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  my_crossover_design <- crossover_designer(N = 300,
#                                            a = .2,
#                                            b = .4,
#                                            crossover = .15)

## ---- eval=FALSE---------------------------------------------------------
#  ??crossover_designer

