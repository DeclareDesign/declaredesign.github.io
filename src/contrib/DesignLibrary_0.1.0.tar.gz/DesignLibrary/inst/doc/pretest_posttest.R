## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(knitr)

## ---- eval = TRUE, code = get_design_code(pretest_posttest_designer())----
N <- 100
ate <- 0.25
rho <- 0.5
attrition_rate <- 0.1

# M: Model
population <- declare_population(
  N = N,
  u_t1 = rnorm(N),
  u_t2 = rnorm(N, u_t1 * rho, sqrt(1 - rho^2)),
  u_i = rnorm(N, 0, sqrt(rho))
)
pos_t1 <- declare_potential_outcomes(Y_t1 ~ u_i + u_t1)
pos_t2 <- declare_potential_outcomes(Y_t2 ~ ate * Z + u_i + u_t2)

# I: Inquiry
estimand <- declare_estimand(ATE = mean(Y_t2_Z_1 - Y_t2_Z_0))

# D: Data Strategy
assignment <- declare_assignment(m = round(N / 2), assignment_variable = Z)
report <- declare_assignment(m = round(N * (1 - attrition_rate)),
                             assignment_variable = R)

# A: Answer Strategy
pretest_lhs <- declare_estimator((Y_t2 - Y_t1) ~ Z,
                                 model = lm_robust,
                                 estimand = estimand,
                                 subset = R == 1,
                                 label = "Change score"
)
pretest_rhs <- declare_estimator(
  Y_t2 ~ Z + Y_t1,
  model = lm_robust,
  estimand = estimand,
  subset = R == 1,
  label = "Condition on pretest"
)
posttest_only <- declare_estimator(
  Y_t2 ~ Z,
  model = lm_robust,
  estimand = estimand,
  label = "Posttest only"
)
# Design
pretest_posttest_design <- population +
  pos_t1 +
  pos_t2 +
  estimand +
  assignment +
  report +
  declare_reveal(Y_t1) +
  declare_reveal(Y_t2) +
  pretest_lhs +
  pretest_rhs +
  posttest_only

## ------------------------------------------------------------------------
diagnosis <- diagnose_design(pretest_posttest_design)

## ---- echo=FALSE---------------------------------------------------------
kable(reshape_diagnosis(diagnosis)[,-c(1,2,4)], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  my_pretest_posttest_design <- pretest_posttest_designer(N = 300,
#                                                          ate = .2,
#                                                          rho = .4,
#                                                          attrition_rate = .15)

## ---- eval=FALSE---------------------------------------------------------
#  ??pretest_posttest_designer

