## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(DesignLibrary)
library(knitr)

## ---- code = get_design_code( mediation_analysis_designer()), eval=TRUE----
N <- 100
a <- 0.5
b <- 0.5
d <- 0.5
rho <- 0.2

population <- declare_population(
  N = N, 
  e1 = rnorm(N),
  e2 = rnorm(n = N, mean = rho * e1, sd = 1 - rho^2)
)
pos_M <-
  declare_potential_outcomes(M ~ a * Z + e1)
pos_Y <-
  declare_potential_outcomes(Y ~ d * Z + b * M + e2)
assignment <- declare_assignment(prob = 0.5)
reveal_mediator <- declare_reveal(M, Z)
reveal_outcome <- declare_reveal(Y, Z) 
mand_a <- declare_estimand(a = a)
mand_b <- declare_estimand(b = b)
mand_d <- declare_estimand(d = d)
mediator_regression <- declare_estimator(
  M ~ Z,
  model = lm_robust,
  coefficients = "Z",
  estimand = mand_a,
  label = "Mediator regression"
)
outcome_regression <- declare_estimator(
  Y ~ Z + M,
  model = lm_robust,
  coefficients = c("M","Z"),
  estimand = c(mand_b,mand_d),
  label = "Outcome regression"
)
mediation_analysis_design <-
  population +
  pos_M +
  assignment +
  reveal_mediator +
  pos_Y +
  mand_a +
  mand_b +
  mand_d +
  reveal_outcome +
  mediator_regression +
  outcome_regression

## ----eval = TRUE---------------------------------------------------------
designs <- expand_design(mediation_analysis_designer, rho = c(0,.5))
diagnosis <- diagnose_design(designs)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[,-1], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github("DeclareDesign/DesignLibrary", keep_source = TRUE)
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  mediation_analysis_design <- mediation_analysis_designer(
#    N = 500, a = .2, b = .4, d = .2, rho = .15)

## ---- eval=FALSE---------------------------------------------------------
#  ??mediation_analysis_designer

