## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(knitr)

## ----eval = TRUE, code = get_design_code(randomized_response_designer())----
N <- 1000
prob_forced_yes <- 0.6
prevalence_rate <- 0.1
withholding_rate <- 0.5

# M: Model
population <- declare_population(
  N = N,
  sensitive_trait = draw_binary(prob = prevalence_rate, N = N),
  withholder = draw_binary(prob = sensitive_trait * withholding_rate, N = N),
  direct_answer =  sensitive_trait - withholder
)
pos <- declare_potential_outcomes(
  Y_Z_Yes = 1,
  Y_Z_Truth = sensitive_trait
)

# I: Inquiry
estimand <- declare_estimand(true_rate = prevalence_rate)

# D: Data Strategy
assignment <- declare_assignment(
  prob = prob_forced_yes,
  conditions = c("Truth","Yes")
)

# A: Answer Strategy
estimator_randomized_response <- declare_estimator(
  handler = tidy_estimator(
    function(data) with(
      data,
      data.frame(est = (mean(Y) - prob_forced_yes) / (1 - prob_forced_yes)))),
  estimand = estimand,
  label = "Forced Randomized Response"
)
estimator_direct_question <- declare_estimator(
  handler = tidy_estimator(function(data) with(
    data,
    data.frame(est = mean(direct_answer)))),
  estimand = estimand,
  label = "Direct Question"
)

# Design
randomized_response_design <- population +
  assignment +
  pos +
  estimand +
  declare_reveal(Y, Z) +
  estimator_randomized_response +
  estimator_direct_question

## ------------------------------------------------------------------------
diagnosis <- diagnose_design(randomized_response_design,
                             diagnosands = declare_diagnosands(bias = mean(est - estimand),
                                                               rmse = sqrt(mean((est - estimand)^2)),
                                                               mean_estimate = mean(est),
                                                               mean_estimand = mean(estimand),
                                                               keep_defaults = FALSE))

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis), digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  my_randomized_response_design <- randomized_response_designer(N = 300,
#                                                                prob_forced_yes = .6,
#                                                                prevalence_rate = .2,
#                                                                withholding_rate = .2)

## ---- eval=FALSE---------------------------------------------------------
#  ??randomized_response_designer

