## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(DesignLibrary)
library(knitr)

## ---- code = get_design_code(simple_spillover_designer()), eval=TRUE-----
n_groups <- 80
group_size <- 3
sd <- 0.2
gamma <- 2

# Model ----------------------------------------------------------------------
population <- declare_population(G = add_level(N = n_groups, n = group_size), 
                          i = add_level(N = n, zeros = 0, ones =1))

dgp <- function(i, Z, G, n) (sum(Z[G == G[i]])/n[i])^gamma + rnorm(1)*sd

# Inquiry --------------------------------------------------------------------
estimand <- declare_estimand(Treat_1 = mean(
  sapply(1:length(G), function(i) {
    Z_i <- (1:length(G))==i
    dgp(i,Z_i,G, n) - dgp(i, zeros, G, n)})
), label = "estimand")

# Data
assignment <- declare_assignment()

reveal <- declare_reveal(handler=fabricate,
                         Y = sapply(1:N, function(i) dgp(i, Z, G, n)))

# Answer Strategy -------------------------------------------------------------
estimator <- declare_estimator(Y ~ Z, estimand = estimand, 
                               model = lm_robust, label = "naive")

# Design ----------------------------------------------------------------------
simple_spillover_design <- population + estimand + assignment + reveal + estimator


## ----eval = TRUE---------------------------------------------------------
diagnosis <- diagnose_design(simple_spillover_design)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[, -c(1,2,3,5)], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github("DeclareDesign/DesignLibrary", keep_source = TRUE)
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  simple_spillover_design <- simple_spillover_designer(n_groups = 40,
#                                                       group_size = 10,
#                                                       sd = .25,
#                                                       gamma = 4)

## ---- eval=FALSE---------------------------------------------------------
#  ??simple_spillover_designer

