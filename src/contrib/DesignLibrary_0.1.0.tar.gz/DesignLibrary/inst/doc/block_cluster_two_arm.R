## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(DesignLibrary)
library(knitr)

## ---- code = get_design_code(block_cluster_two_arm_designer(N_blocks = 4, N_clusters_in_block = 4, N_i_in_cluster = 5,sd_cluster = 2)), eval=TRUE----
N_blocks <- 4
N_clusters_in_block <- 4
N_i_in_cluster <- 5
sd_block <- 0.2
sd_cluster <- 2
sd_i_0 <- sqrt(max(0, 1 - sd_block^2 - sd_cluster^2))
sd_i_1 <- sd_i_0
prob <- 0.5
control_mean <- 0
ate <- 1
treatment_mean <- control_mean + ate
rho <- 1

# M: Model
population <- declare_population(
  blocks   = add_level(
    N = N_blocks,
    u_b = rnorm(N) * sd_block),
  clusters = add_level(
    N = N_clusters_in_block,
    u_c = rnorm(N) * sd_cluster,
    cluster_size = N_i_in_cluster),
  i = add_level(
    N   = N_i_in_cluster,
    u_0 = rnorm(N),
    u_1 = rnorm(n = N, mean = rho * u_0, sd = sqrt(1 - rho^2)))
  )

pos <- declare_potential_outcomes(
  Y ~ (1 - Z) * (control_mean    + u_0*sd_i_0 + u_b + u_c) + 
      Z *       (treatment_mean  + u_1*sd_i_1 + u_b + u_c) )

# I: Inquiry
estimand <- declare_estimand(ATE = mean(Y_Z_1 - Y_Z_0))

# D: Data
assignment <- declare_assignment(prob = prob,
                                 blocks = blocks,
                                 clusters = clusters)

# A: Analysis
est <- declare_estimator(
  Y ~ Z,
  estimand = estimand,
  model = difference_in_means,
  blocks = blocks,
  clusters = clusters
)

# Design
block_cluster_two_arm_design <-  population + pos + estimand + assignment + 
  declare_reveal() + est

## ----eval = TRUE---------------------------------------------------------
individual_var <- block_cluster_two_arm_designer(N_blocks = 50, 
                                                 N_clusters_in_block = 2, 
                                                 N_i_in_cluster = 10, 
                                                 sd_block = 0,
                                                 sd_i_0 = 1.01,
                                                 sd_i_1 = 1.01,
                                                 sd_cluster = 0,
                                                 ate = .25)
cluster_var <- block_cluster_two_arm_designer(N_blocks = 50, 
                                              N_clusters_in_block = 2,
                                              N_i_in_cluster = 10, 
                                              sd_block = 0,
                                              sd_i_0 = .01,
                                              sd_i_1 = .01,
                                              sd_cluster = 1,
                                              ate = .25)
block_var <- block_cluster_two_arm_designer(N_blocks = 50, 
                                            N_clusters_in_block = 2,
                                            N_i_in_cluster = 10, 
                                            sd_block = 1,
                                            sd_i_0 = .01,
                                            sd_i_1 = .01,
                                            sd_cluster = 0,
                                            ate = .25)
diagnosis <- diagnose_design(individual_var, cluster_var, block_var)

## ----eval = TRUE, echo = FALSE-------------------------------------------
kable(reshape_diagnosis(diagnosis)[, -c(1:2, 4:6, 13,14)], digits = 2)

## ---- eval=FALSE---------------------------------------------------------
#  devtools::install_github("DeclareDesign/DesignLibrary", keep_source = TRUE)
#  library(DesignLibrary)

## ---- eval=FALSE---------------------------------------------------------
#  block_cluster_two_arm_design <- block_cluster_two_arm_designer(N_blocks = 50,
#                                                                 N_clusters_in_block = 30,
#                                                                 N_i_in_cluster = 200,
#                                                                 sd_block = .5,
#                                                                 sd_cluster = .5,
#                                                                 sd_i_0 = .3,
#                                                                 sd_i_1 = .6,
#                                                                 prob = .5,
#                                                                 control_mean = 0,
#                                                                 treatment_mean = .2)

## ---- eval=FALSE---------------------------------------------------------
#  ??block_cluster_two_arm_designer

