library(testthat)
library(DesignLibrary)

test_check(package = "DesignLibrary")
