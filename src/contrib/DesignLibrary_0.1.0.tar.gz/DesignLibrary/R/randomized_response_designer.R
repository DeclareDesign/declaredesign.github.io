#' Create a randomized response design
#'
#' A forced randomized response design that measures the share of individuals with a given trait \code{prevalence_trait} in a population of size \code{N}. Probability of forced response ("Yes") is given by \code{prob_forced_yes}, and rate at which individuals with trait lie is given by \code{withholding_rate}.
#' 
#' Key limitations: This design employs a specific variation of randomized response that randomly requires respondents to provide a fixed answer to the sensitive question (see Blair, Imai, and Zhou (2015) for alternative applications and estimation strategies).
#' 
#'
#' @param N An integer. Size of sample.
#' @param prob_forced_yes A number. Probability of a forced yes.
#' @param prevalence_rate A number. Probability that individual has the sensitive trait.
#' @param withholding_rate A number. Probability that an individual with the sensitive trait hides it.
#' @return A randomized response design.
#' @author \href{https://declaredesign.org/}{DeclareDesign Team}
#' @concept experiment
#' @concept descriptive
#' @export
#'
#' @examples
#' # To make a design using default arguments:
#' randomized_response_design <- randomized_response_designer()

randomized_response_designer <- function(
  N = 1000,
  prob_forced_yes = .6,
  prevalence_rate = .1,
  withholding_rate = .5
){
  {{{
    # M: Model
    population <- declare_population(
      N = N,
      sensitive_trait = draw_binary(prob = prevalence_rate, N = N),
      withholder = draw_binary(prob = sensitive_trait * withholding_rate, N = N),
      direct_answer =  sensitive_trait - withholder
    )
    potential_outcomes <- declare_potential_outcomes(
      Y_Z_Yes = 1,
      Y_Z_Truth = sensitive_trait
    )
    # I: Inquiry
    estimand <- declare_estimand(true_rate = prevalence_rate)
    # D: Data strategy
    coin_flip <- declare_assignment(
      prob = prob_forced_yes,
      conditions = c("Truth","Yes")
    )
    # A: Answer strategy
    randomized_response_estimator <- declare_estimator(
      handler = tidy_estimator(
        function(data) with(
          data,
          data.frame(est = (mean(Y) - prob_forced_yes) / (1 - prob_forced_yes)))),
      estimand = estimand,
      label = "Forced Randomized Response"
    )
    direct_question_estimator <- declare_estimator(
      handler = tidy_estimator(function(data) with(
        data,
        data.frame(est = mean(direct_answer)))),
      estimand = estimand,
      label = "Direct Question"
    )
    # Design
    randomized_response_design <- population +
      coin_flip +
      potential_outcomes +
      estimand +
      declare_reveal(Y, Z) +
      randomized_response_estimator +
      direct_question_estimator
  }}}
  attr(randomized_response_design, "code") <- 
    construct_design_code(randomized_response_designer, match.call.defaults())
  randomized_response_design
}
attr(randomized_response_designer,"tips") <-
  list(
    N = "Size of sample",
    prob_forced_yes = "Probability of forced 'yes' response",
    prevalence_rate = "True rate of sensitive trait presence in population",
    withholding_rate = "Rate at which those with sensitive trait conceal it when asked directly"
  )
attr(randomized_response_designer,"shiny_arguments") <-
  list(
    N = c(1000, 1500, 2000, 2500),
    prob_forced_yes = c(.6,seq(.1,.9,.1)),
    prevalence_rate = c(.1,seq(.05,.95,.1)),
    withholding_rate = c(.5,seq(.05,.95,.1))
  )
attr(randomized_response_designer,"description") <- "
<p> A forced randomized response design that measures the share of individuals with a given trait (whose value is defined by <code>prevalence_trait</code>) in a population of size <code>N</code>. Probability of forced response ('Yes') is given by <code>prob_forced_yes</code>, and rate at which individuals with trait lie is defined by <code>withholding_rate</code>.
"

