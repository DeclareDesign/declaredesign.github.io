#' DesignLibrary: A package for creating designs
#'
#' 
#' 
#' @docType package
#' 
#' @name DesignLibrary