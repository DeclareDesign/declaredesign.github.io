#' randomizr
#'
#' @name randomizr
#' @docType package
NULL
