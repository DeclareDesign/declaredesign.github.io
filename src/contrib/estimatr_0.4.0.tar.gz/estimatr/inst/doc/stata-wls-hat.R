## ---- echo = FALSE-------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
# Using estimatr
library(estimatr)
lm_robust(
  mpg ~ hp, 
  data = mtcars, 
  weights = wt, 
  se_type = "HC2"
)

