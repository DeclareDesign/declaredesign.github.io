## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, digits = 3, fig.width = 4, fig.height = 3)
fname <- "simulations-debias-dim.rda"
rerun <- !file.exists(fname)
if (!rerun) {
  load(fname)
} 

## ------------------------------------------------------------------------
library(DeclareDesign)

## ------------------------------------------------------------------------
# Define population with blocks of the same size, with some block-level shock
simp_blocks <- declare_population(
  blocks = add_level(
    N = 40,
    block_shock = runif(N, 0, 10)
  ),
  individual = add_level(
    N = 8,
    epsilon = rnorm(N)
  )
)
# Block shocks influnce Y_Z_1, the treatment potential outcome
blocked_pos <- declare_potential_outcomes(Y ~ Z * 0.5 * block_shock + epsilon)
# Complete random assignment of half of units in each block
blocked_assign <- declare_assignment(blocks = blocks, prob = 0.5)
# Estimand is the ATE
ate <- declare_estimand(ATE = mean(Y_Z_1 - Y_Z_0))

## ------------------------------------------------------------------------
dim <- declare_estimator(Y ~ Z, label = "DIM")
dim_bl <- declare_estimator(Y ~ Z, blocks = blocks, label = "DIM blocked")

# Our design
simp_bl_des <- declare_design(
  simp_blocks,
  blocked_pos,
  blocked_assign,
  ate,
  dim, 
  dim_bl
)

# Our diagnosands of interest
my_diagnosands <- declare_diagnosands(
  `Bias` = mean(est - estimand),
  `Coverage` =  mean(estimand <= ci_upper & estimand >= ci_lower),
  `Mean of Estimated ATE` = mean(est),
  `Mean of True ATE (Estimand)` = mean(estimand),
  `Mean Standard Error` = mean(se)
)

## ------------------------------------------------------------------------
dat <- draw_data(simp_bl_des)
plot(dat$blocks, dat$Y_Z_1, 
     ylab = "Y_Z_1 (treatment PO)", xlab = "Block ID")

## ---- eval=rerun, echo = 1:6---------------------------------------------
#  set.seed(42)
#  simp_bl_dig <- diagnose_design(
#    simp_bl_des,
#    sims = 5000,
#    diagnosands = my_diagnosands
#  )
#  simp_bl_dig$simulations <- NULL

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(simp_bl_dig$diagnosands[, c(
    "Mean of True ATE (Estimand)", "Mean of Estimated ATE",
    "Bias", "se(Bias)",
    "Coverage", "se(Coverage)",
    "Mean Standard Error", "se(Mean Standard Error)"
  )]),
  col.names = c("Naive DIM", "Block DIM"),
  digits = 3
)

## ------------------------------------------------------------------------
corr_blocks <- declare_population(
  blocks = add_level(
    N = 60,
    block_shock = runif(N, 0, 10),
    indivs_per_block = 8,
    # if block shock is > 5, treat 6 units, otherwise treat 2
    m_treat = ifelse(block_shock > 5, 6, 2)
  ),
  individual = add_level(
    N = indivs_per_block,
    epsilon = rnorm(N, sd = 3)
  )
)
# Use same potential outcomes as above, but now treatment probability varies across blocks
corr_blocked_assign <- declare_assignment(
  blocks = blocks, 
  # The next line will just get the number of treated for a block from
  # the first unit in that block
  block_m = m_treat[!duplicated(blocks)]
)
corr_bl_des <- declare_design(
  corr_blocks,
  blocked_pos,
  corr_blocked_assign,
  ate,
  dim, 
  dim_bl
)

## ------------------------------------------------------------------------
dat <- draw_data(corr_bl_des)
plot(factor(dat$m_treat / 8), dat$Y_Z_1 - dat$Y_Z_0, 
     ylab = "True treat. effect", xlab = "Pr treatment in block")

## ---- eval=rerun, echo = 1:7---------------------------------------------
#  set.seed(42)
#  corr_bl_dig <- diagnose_design(
#    corr_bl_des,
#    sims = 5000,
#    diagnosands = my_diagnosands,
#    parallel = TRUE
#  )
#  corr_bl_dig$simulations <- NULL

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(corr_bl_dig$diagnosands[, c(
    "Mean of True ATE (Estimand)", "Mean of Estimated ATE",
    "Bias", "se(Bias)",
    "Coverage", "se(Coverage)",
    "Mean Standard Error", "se(Mean Standard Error)"
  )]),
  col.names = c("Naive DIM", "Block DIM"),
  digits = 3
)

## ------------------------------------------------------------------------
# Define clustered data
simp_clusts <- declare_population(
  clusters = add_level(
    N = 40,
    clust_shock = runif(N, 0, 10)
  ),
  individual = add_level(
    N = 8,
    epsilon = rnorm(N)
  )
)
# Treatment potential outcomes correlated with cluster shock
clustered_POs <- declare_potential_outcomes(Y ~ Z * 0.2 * clust_shock + epsilon)

# Clustered assignment to treatment
clustered_assign <- declare_assignment(clusters = clusters, prob = 0.5)

ate <- declare_estimand(ATE = mean(Y_Z_1 - Y_Z_0))

# Specify our two estimators
dim <- declare_estimator(Y ~ Z, label = "DIM")
dim_cl <- declare_estimator(Y ~ Z, clusters = clusters, label = "DIM clustered")

simp_cl_des <- declare_design(
  simp_clusts,
  clustered_POs,
  clustered_assign,
  ate,
  dim,
  dim_cl
)

## ------------------------------------------------------------------------
dat <- draw_data(simp_cl_des)
table(Z = dat$Z, clusters = dat$clusters)

## ------------------------------------------------------------------------
plot(dat$clusters, dat$Y_Z_1,
     ylab = "Y_Z_1 (treatment PO)", xlab = "Cluster ID")

## ---- eval=rerun, echo = 1:6---------------------------------------------
#  set.seed(42)
#  simp_cl_dig <- diagnose_design(
#    simp_cl_des,
#    sims = 5000,
#    diagnosands = my_diagnosands
#  )
#  simp_cl_dig$simulations <- NULL

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(simp_cl_dig$diagnosands[, c(
    "Mean of True ATE (Estimand)", "Mean of Estimated ATE",
    "Bias", "se(Bias)",
    "Coverage", "se(Coverage)",
    "Mean Standard Error", "se(Mean Standard Error)"
  )]),
  col.names = c("Naive DIM", "Cluster DIM"),
  digits = 3
)

## ------------------------------------------------------------------------
# Correlated cluster size and potential outcomes
diff_size_cls <- declare_population(
  clusters = add_level(
    N = 10,
    clust_shock = runif(N, 0, 10),
    indivs_per_clust = ceiling(clust_shock),
    condition_pr = 0.5
  ),
  individual = add_level(
    N = indivs_per_clust,
    epsilon = rnorm(N, sd = 3)
  )
)
clustered_POs <- declare_potential_outcomes(Y ~ Z * 0.4 * clust_shock + epsilon)

ht_cl <- declare_estimator(
  formula = Y ~ Z,
  # Give your randomization declaration to HT and it sorts it out!
  declaration = randomizr::declare_ra(clusters = with(data, clusters), prob = 0.5),
  model = estimatr::horvitz_thompson,
  label = "Horvitz-Thompson Clustered"
)

diff_cl_des <- declare_design(
  diff_size_cls,
  clustered_POs,
  clustered_assign,
  ate,
  dim_cl,
  ht_cl
)

## ---- eval=rerun, echo = 1:6---------------------------------------------
#  set.seed(41)
#  diff_cl_dig <- diagnose_design(
#    diff_cl_des,
#    sims = 50000,
#    diagnosands = my_diagnosands
#  )
#  diff_cl_dig$simulations <- NULL

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(diff_cl_dig$diagnosands[, c(
    "Mean of True ATE (Estimand)", "Mean of Estimated ATE",
    "Bias", "se(Bias)",
    "Coverage", "se(Coverage)",
    "Mean Standard Error", "se(Mean Standard Error)"
  )]),
  col.names = c("Cluster DIM", "Clust. Horvitz-Thompson"),
  digits = 3
)

## ----save-rds, eval=rerun, include = FALSE-------------------------------
#  save(simp_bl_dig, corr_bl_dig, simp_cl_dig, diff_cl_dig, file = fname)

## ----todo, include=FALSE, eval=FALSE-------------------------------------
#  # Matched-pairs

