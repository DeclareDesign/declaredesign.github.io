## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
fname <- "simulations-ols-var.rda"
rerun <- !file.exists(fname)
if (!rerun) {
  load(fname)
} 

## ------------------------------------------------------------------------
library(DeclareDesign)
library(ggplot2)

## ----draw-fix-x----------------------------------------------------------
set.seed(41)
dat <- data.frame(x = rnorm(50))

## ------------------------------------------------------------------------
sigmasq <- 4
# Build the X matrix with intercept
Xmat <- cbind(1, dat$x)
# Invert XtX
XtX_inv <- solve(crossprod(Xmat))
# Get full variance covariance matrix
true_var_cov_mat <- sigmasq * XtX_inv

## ------------------------------------------------------------------------
true_varb <- true_var_cov_mat[2, 2]
true_varb

## ------------------------------------------------------------------------
simp_pop <- declare_population(
  epsilon = rnorm(N, sd = 2),
  y = x + epsilon
)

## ------------------------------------------------------------------------
varb_estimand <- declare_estimand(true_varb = true_varb)

## ------------------------------------------------------------------------
lmc <- declare_estimator(
  y ~ x,
  model = estimatr::lm_robust, 
  se_type = "classical",
  estimand = varb_estimand,
  coefficient_name = "x"
)

## ------------------------------------------------------------------------
# First declare all the steps of our design, starting with our fixed data
classical_design <- declare_design(
  dat,
  simp_pop,
  varb_estimand,
  lmc
)

# Declare a set of diagnosands that help us check if 
# we have unbiasedness
my_diagnosands <- declare_diagnosands(
  `Bias of Estimated Variance` = mean(se^2 - estimand),
  `Bias of Standard Error` = mean(se - sd(est)),
  `Coverage Rate` = mean(1 <= ci_upper & 1 >= ci_lower),
  `Mean of Estimated Variance` = mean(se^2),
  `True Variance` = estimand[1]
)

## ---- eval=rerun, echo=1:8-----------------------------------------------
#  # Run 25000 simulations
#  set.seed(42)
#  dig <- diagnose_design(
#    classical_design,
#    sims = 20000,
#    diagnosands = my_diagnosands,
#    parallel = TRUE
#  )
#  dig$simulations <- data.frame(var = dig$simulations$se^2)

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(dig$diagnosands[, c(
    "True Variance", "Mean of Estimated Variance",
    "Bias of Estimated Variance", "se(Bias of Estimated Variance)"
  )]),
  col.names = c("Diagnosand"),
  digits = 5
)

## ---- warning = FALSE, echo = FALSE, fig.width=5, fig.height=4-----------
# Get cuts to add label for true variance
sumvar <- summary(dig$simulations$var)
ggplot(dig$simulations, aes(x = var)) +
  geom_density() +
  geom_vline(xintercept = true_varb, size = 1, color = "red") +
  labs(x = "Estimated Variance") +
  theme_classic()

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(dig$diagnosands[
    , 
    c(
      "Bias of Standard Error", "se(Bias of Standard Error)",
      "Coverage Rate", "se(Coverage Rate)"
    )
  ]),
  col.names = c("Diagnosand"),
  digits = 5
)

## ---- fig.width=4, fig.height=3------------------------------------------
dat <- fabricate(
  dat,
  noise_var = 1 + (x - min(x))^2
)
# Plot shows variance of errors increasing with x
plot(dat$x, dat$noise_var, xlab = "x", ylab = "sigmasq_i")

## ------------------------------------------------------------------------
Xmat <- with(dat, cbind(1, x))
XtX_inv <- solve(crossprod(Xmat))
varb <- tcrossprod(XtX_inv, Xmat) %*% diag(with(dat, noise_var)) %*% Xmat %*% XtX_inv
true_varb_het <- varb[2, 2]
true_varb_het

## ------------------------------------------------------------------------
# This creates a template that takes some fixed data
# that has x and noise_var. Then for that data, it creates
# a single design that you can then simulate many times to get
# the properties you are interested in
# It also takes the two se_types you'd like to compare
fixed_dat_het_design_temp <- function(dat, se_types) {
  
  # Get true variance for this data
  Xmat <- with(dat, cbind(1, x))
  XtX_inv <- solve(crossprod(Xmat))
  varb <- tcrossprod(XtX_inv, Xmat) %*% diag(with(dat, noise_var)) %*% Xmat %*% XtX_inv
  true_varb_het <- varb[2, 2]
  
  # Population function now has heteroskedastic noise
  simp_pop <- declare_population(
    epsilon = rnorm(N, sd = sqrt(noise_var)),
    y = x + epsilon
  )

  varb_het_estimand <- declare_estimand(true_varb_het = true_varb_het)

  # Now we declare the two estimators
  lm1 <- declare_estimator(
    y ~ x,
    model = estimatr::lm_robust,
    se_type = !!se_types[1], # !! operater will reveal the value and pass it to estimatr
    estimand = varb_het_estimand,
    coefficient_name = "x",
    label = se_types[1]
  )
  
  lm2 <- declare_estimator(
    y ~ x, 
    model = estimatr::lm_robust, 
    se_type = !!se_types[2],
    estimand = varb_het_estimand,
    coefficient_name = "x",
    label = se_types[2]
  )
  
  # We return the design so we can diagnose it
  return(
    declare_design(
      dat,
      simp_pop,
      varb_het_estimand,
      lm1, 
      lm2
    )
  )
}

## ---- eval=rerun, echo=1:3-----------------------------------------------
#  # Create a design using our template and the data we have been using
#  het_design <- fixed_dat_het_design_temp(dat, se_types = c("classical", "HC2"))
#  
#  dig_het <- diagnose_design(
#    het_design,
#    sims = 10000,
#    diagnosands = my_diagnosands,
#    parallel = TRUE
#  )
#  dig_het$simulations <- NULL

## ---- echo = FALSE-------------------------------------------------------
knitr::kable(
  t(dig_het$diagnosands[
    , 
    c(
      "True Variance", "Mean of Estimated Variance",
      "Bias of Estimated Variance", "se(Bias of Estimated Variance)",
      "Bias of Standard Error", "se(Bias of Standard Error)",
      "Coverage Rate", "se(Coverage Rate)"
    )
  ]),
  col.names = c("Classical Est.", "HC2"),
  digits = 5
)

## ---- eval=rerun---------------------------------------------------------
#  Ns <- c(100, 500, 1000, 2500, 5000)
#  diags <- vector("list", length(Ns))
#  
#  set.seed(42)
#  for (i in seq_along(Ns)) {
#    # Generate ONE fixed dataset per N
#    dat <- fabricate(
#      N = Ns[i],
#      x = rnorm(N),
#      noise_var = 1 + (x - min(x))^2
#    )
#    des <- fixed_dat_het_design_temp(dat, se_types = c("classical", "HC2"))
#    diags[[i]] <- diagnose_design(
#      des,
#      sims = 10000,
#      diagnosands = my_diagnosands,
#      bootstrap = FALSE
#    )$diagnosands
#    diags[[i]]$N <- Ns[i]
#  }

## ---- warning = FALSE, echo = FALSE, fig.width=5, fig.height=4-----------
plotdf <- do.call(rbind, diags)
ggplot(plotdf, aes(x = N, y = `Bias of Estimated Variance`, color = estimator_label)) +
  geom_point() +
  geom_hline(yintercept = 0, linetype = 2, color = "grey") +
  labs(color = "Estimator") +
  theme_classic()

## ----hc1-hc2, eval=rerun-------------------------------------------------
#  datasets <- 40
#  # Generate several fixed datasets per N
#  Ns <- rep(c(15, 25, 50), each = datasets)
#  diags_hc <- vector("list", length(Ns))
#  
#  set.seed(42)
#  for (i in seq_along(Ns)) {
#    dat <- fabricate(
#      N = Ns[i],
#      x = rnorm(N),
#      noise_var = 1 + (x - min(x))^2
#    )
#    des <- fixed_dat_het_design_temp(dat, se_types = c("HC1", "HC2"))
#    diags_hc[[i]] <- diagnose_design(
#      des,
#      sims = 200,
#      diagnosands = my_diagnosands,
#      bootstrap = FALSE
#    )$diagnosands
#    diags_hc[[i]]$N <- Ns[i]
#  }

## ---- echo = FALSE, fig.height = 4, fig.width = 5------------------------
plotdf <- do.call(rbind, diags_hc)
ggplot(plotdf, aes(x = factor(N), y = `Bias of Estimated Variance`,  group = interaction(N, estimator_label), color = estimator_label)) + 
  geom_hline(yintercept = 0, linetype = 2, color = "grey") +
  geom_boxplot() +
  labs(x = "N", color = "Variance Estimator") + 
  theme_classic()

## ----save-rds, eval=rerun, include = FALSE-------------------------------
#  save(dig, dig_het, diags, diags_hc, file = fname)

## ----todo, eval = FALSE, include = FALSE---------------------------------
#  # Stochastic data
#  # Clusters

