library(testthat)
library(fabricatr)

test_check("fabricatr")
