## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ----echo=TRUE, results="hide"-------------------------------------------
voter_turnout = draw_binary(prob = 0.4, N = 100)

table(voter_turnout)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(voter_turnout))

## ----results="hide"------------------------------------------------------
population <- fabricate(
  N = 100,
  age = round(runif(N, 18, 85)),
  turnout = draw_binary(prob = ifelse(age < 40, 0.4, 0.7), N=N)
)

## ----echo=FALSE, fig.width=7, fig.height=3-------------------------------
latent_example = function(x, density_x) {
  current_margins = par("mar")
  density_x = 0.4 * (density_x / max(density_x))
  par(mar=c(1,1,1,1))
  plot(x,
       density_x,
       main="",
       xaxt="n",
       yaxt="n",
       type="l",
       bty="n",
       xlim=c(-3, 3),
       ylim=c(-0.2, 0.5)
  )
  text(0, -0.1, "Latent Variable")

  for(x in c(-1.5, -0.5, 0.5, 1.5)) {
    lines(c(x, x), c(-0.03, 0.5), lty=2, col="lightgrey")
  }
  text(-2, 0.45, "Strongly Disagree")
  text(-1, 0.45, "Disagree")
  text(0, 0.45, "Neutral")
  text(1, 0.45, "Agree")
  text(2, 0.45, "Strongly Agree")

  lines(c(-2.8, 2.8), c(-0.03, -0.03))
  lines(c(-2.7, -2.8, -2.7), c(0, -0.03, -0.06))
  lines(c(2.7, 2.8, 2.7), c(0, -0.03, -0.06))
  par(mar=current_margins)
}

latent_example(x = seq(-2.8, 2.8, 0.001), density_x = dnorm(seq(-2.8, 2.8, 0.001)))

## ----echo=FALSE, fig.width=7, fig.height=3-------------------------------
latent_example(x = seq(-2.8, 2.8, 0.001), density_x = dnorm(seq(-3.8, 1.8, 0.001), sd=0.5))

## ----results="hide"------------------------------------------------------
mayor_approval <- draw_ordered(x = rnorm(n = 100),
                               breaks = c(-1.5, -0.5, 0.5, 1.5),
                               break_labels = c("Strongly Disagree", "Disagree",
                                                "Neutral", "Agree",
                                                "Strongly Agree"))

table(mayor_approval)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(mayor_approval))

## ----echo=FALSE, fig.width=7, fig.height=3-------------------------------
latent_example_parties = function(x, density_x, density_x2) {
  current_margins = par("mar")
  max_density = max(max(density_x), max(density_x2))
  density_x = 0.4 * (density_x / max_density)
  density_x2 = 0.4 * (density_x2 / max_density)
  par(mar=c(1,1,1,1))
  plot(x,
       density_x,
       col="red",
       main="",
       xaxt="n",
       yaxt="n",
       type="l",
       bty="n",
       xlim=c(-3, 3),
       ylim=c(-0.2, 0.5)
  )
  lines(x, density_x2, col="blue")
  text(0, -0.1, "Latent Variable")

  for(x in c(-1.5, -0.5, 0.5, 1.5)) {
    lines(c(x, x), c(-0.03, 0.5), lty=2, col="lightgrey")
  }
  text(-2, 0.45, "Strongly Disagree")
  text(-1, 0.45, "Disagree")
  text(0, 0.45, "Neutral")
  text(1, 0.45, "Agree")
  text(2, 0.45, "Strongly Agree")

  lines(c(-2.8, 2.8), c(-0.03, -0.03))
  lines(c(-2.7, -2.8, -2.7), c(0, -0.03, -0.06))
  lines(c(2.7, 2.8, 2.7), c(0, -0.03, -0.06))
  par(mar=current_margins)
}

latent_example_parties(x = seq(-2.8, 2.8, 0.001),
               density_x = dnorm(seq(-3.8, 1.8, 0.001), sd=0.7),
               density_x2 = dnorm(seq(-1.8, 3.8, 0.001), sd=0.7)
               )

## ----results="hide"------------------------------------------------------
respondent_data <- fabricate(
  N = 100,
  mayor_copartisan = draw_binary(prob = 0.6, N),
  mayor_approval = draw_ordered(
    x = rnorm(N, mean = -1 + 2 * mayor_copartisan),
    breaks = c(-1.5, -0.5, 0.5, 1.5),
    break_labels = c("Strongly Disagree", "Disagree", "Neutral",
                     "Agree", "Strongly Agree")
  )
)

table(respondent_data$mayor_approval, respondent_data$mayor_copartisan)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(respondent_data$mayor_approval, respondent_data$mayor_copartisan))

## ----results="hide"------------------------------------------------------
mayor_approval <- draw_ordered(x = runif(n = 100, min = -2.5, max = 2.5),
                               breaks = c(-1.5, -0.5, 0.5, 1.5),
                               break_labels = c("Strongly Disagree", "Disagree",
                                                "Neutral", "Agree",
                                                "Strongly Agree"))

## ----results="hide"------------------------------------------------------
mayor_approval <- draw_likert(x = rnorm(n = 100),
                              type = 4)

table(mayor_approval)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(mayor_approval))

## ----echo=FALSE----------------------------------------------------------
total_pop = 38610097
group_counts = c(6622576, 5338666, 4967328, 4044440, 841622)
other_count = total_pop - sum(group_counts)
display_counts = c(group_counts, other_count)
names(display_counts) = c("Kikuyu", "Luhya", "Kalenjin", "Luo", "Maasai", "Other")
prop.table(display_counts)

## ----results="hide"------------------------------------------------------
respondent_ethnicity <- draw_categorical(
  prob = c(0.172, 0.138, 0.129, 0.105, 0.022, 0.435),
  category_labels = c("Kikuyu", "Luhya", "Kalenjin", "Luo", "Maasai", "Other"),
  N = 100)

table(respondent_ethnicity)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(respondent_ethnicity))

## ----results="hide"------------------------------------------------------
set.seed(19861108)

efficacy_experiment <- fabricate(
  N = 1000,
  treatment = draw_binary(0.5, N),
  pre_outcome = rnorm(N, mean = 70, sd = 15),
  post_outcome = pre_outcome + rnorm(N,
                                     mean = ifelse(treatment, 15, 0),
                                     sd = 10)
)

## ----results="hide"------------------------------------------------------
set.seed(19861108)

fixed_efficacy_experiment <- fabricate(
  N = 1000,
  treatment = draw_binary(0.5, N),
  pre_outcome = pmin(
    pmax(rnorm(N, mean = 70, sd = 15), 0),
    100),
  post_outcome = pmin(
    pmax(pre_outcome + rnorm(N,
                             mean = ifelse(treatment, 15, 0),
                             sd = 10), 0),
    100)
)

## ----echo=FALSE, fig.width=7, fig.height=3-------------------------------
hist(fixed_efficacy_experiment$post_outcome,
     main = "Histogram of post-treatment outcomes",
     yaxt = "n",
     breaks=c(0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100),
     xlab = "Post-Treatment Outcome: Score from 0 to 100")

## ----echo=FALSE, fig.width=7, fig.height=3-------------------------------
plot(seq(0, 10, by=0.01),
     dlnorm(seq(0, 10, by=0.01)),
     type="l",
     main="Hypothesized distribution of Radio Coverage",
     xlab="Density of Radio Coverage",
     xaxt="n",
     yaxt="n",
     ylab="Number of observations")
axis(side = 1,
     at = c(0, 0.5, 10),
     labels = c("0", "Low", "High"))

## ----results="hide"------------------------------------------------------
rtlme_model <- fabricate(
  N = 1000,
  radio_coverage = rlnorm(N, meanlog=0, sdlog=1),
  violent_incident_count = draw_count(mean = 1.5 * radio_coverage, N = N)
)

## ----echo=FALSE----------------------------------------------------------
plot(
  rtlme_model$radio_coverage,
  rtlme_model$violent_incident_count,
  col="lightgrey",
  cex=0.7,
  main="Imagined Data: Radio Coverage versus violence",
  xlab="Radio Coverage",
  ylab="Violent Incidents"
)
fit_loess <- loess(violent_incident_count ~ radio_coverage, data=rtlme_model)
loess_np <- predict(fit_loess, nedata=rtlme_model$radio_coverage, se=TRUE)
min_set <- loess_np$fit - 1.96 * loess_np$se.fit
max_set <- loess_np$fit + 1.96 * loess_np$se.fit
ordered_x <- order(rtlme_model$radio_coverage)
rug(rtlme_model$radio_coverage)
lines(rtlme_model$radio_coverage[ordered_x],
      fit_loess$fitted[ordered_x],
      col="red"
      )
lines(rtlme_model$radio_coverage[ordered_x],
      max_set[ordered_x],
      lty = 2,
      col="red")
lines(rtlme_model$radio_coverage[ordered_x],
      min_set[ordered_x],
      lty = 2,
      col="red")

## ----results="hide"------------------------------------------------------
population_data <- fabricate(
  N = 1000,
  income = 20000 * rgamma(N, 1.4, 0.65)
)

