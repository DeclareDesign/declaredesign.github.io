## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ----echo=TRUE, results="hide"-------------------------------------------
variable_data <-
  fabricate(
    cities = add_level(N = 2, elevation = runif(n = N, min = 1000, max = 2000)),
    citizens = add_level(N = c(2, 4), age = runif(N, 18, 70))
  )
variable_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(variable_data)

## ----echo=TRUE, results="hide"-------------------------------------------
my_data <-
  fabricate(
    cities = add_level(N = 2, elevation = runif(n = N, min = 1000, max = 2000)),
    citizens = add_level(N = sample(1:6, size = 2, replace = TRUE), age = runif(N, 18, 70))
  )
my_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(my_data)

## ----echo=TRUE, results="hide"-------------------------------------------
variable_n <- fabricate(
  cities = add_level(N = 5, population = runif(N, 10, 200)),
  citizens = add_level(N = round(population * 0.3))
)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(head(variable_n))

## ----echo=TRUE, results="hide"-------------------------------------------
n_inherit <- fabricate(
  cities = add_level(N = 5, population = runif(N, 10, 200)),
  citizens = add_level(N = sample(1:10, length(cities), replace=TRUE))
)

## ----results="hide"------------------------------------------------------
# Load external data: Thanks to Tony McGovern, https://github.com/tonmcg
county_level_2016_results <- read.csv(url("https://raw.githubusercontent.com/tonmcg/County_Level_Election_Results_12-16/master/2016_US_County_Level_Presidential_Results.csv"))

# Function that takes quantile_y and maps to the empirical quantiles of dataset
custom_quantile <- function(data, quantile_y) {
  round(ecdf(data)(quantile_y), 2)
}

# Traditional fabricate() call:
county_vote_data <- fabricate(
  N = 500,
  poverty_rate = runif(N, min = 0.01, max = 0.40),
  dem_vote = correlate(custom_quantile, 
                       data = county_level_2016_results$per_dem,
                       given = poverty_rate, 
                       rho = 0.3)
)

cor(county_vote_data$dem_vote, county_vote_data$poverty_rate, method="spearman")

## ---- message=FALSE, echo=TRUE, results="hide"---------------------------
library(dplyr)

my_data <-
  fabricate(
    cities = add_level(N = 2, elevation = runif(n = N, min = 1000, max = 2000)),
    citizens = add_level(N = c(2, 3), age = runif(N, 18, 70))
  ) %>%
  group_by(cities) %>%
  mutate(pop = n())

my_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(my_data)

## ----echo=TRUE, results="hide"-------------------------------------------
my_data <-
  data_frame(Y = sample(1:10, 2)) %>%
  fabricate(lower_level = add_level(N = 3, Y2 = Y + rnorm(N)))
my_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(my_data)

