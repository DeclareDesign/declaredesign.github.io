
`%i%` <- intersect

`%icn%` <- function(e1, e2) e1 %i% colnames(e2)
