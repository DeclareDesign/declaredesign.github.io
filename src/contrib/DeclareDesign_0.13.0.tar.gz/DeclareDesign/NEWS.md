# DeclareDesign 0.12.0

* Add ability to use `get_estimates` with data, useful for example for getting estimates after data is collected for a study. To draw estimates or estimands from simulated data, now use renamed `draw_estimates` and `draw_estimands` functions.
* Documentation improvements
* Bug fixes

# DeclareDesign 0.10.0

* First CRAN version
