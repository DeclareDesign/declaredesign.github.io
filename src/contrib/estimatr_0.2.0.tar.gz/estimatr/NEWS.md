# estimatr 0.2.0

* Initial package submission to **CRAN**
