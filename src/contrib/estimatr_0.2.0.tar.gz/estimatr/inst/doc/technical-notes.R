## ---- echo = FALSE-------------------------------------------------------
set.seed(42)
knitr::opts_chunk$set(
  collapse = TRUE, 
  comment = "#>"
)
options(digits = 2)

## ----dropthis, include=FALSE, eval=FALSE---------------------------------
#  Weighted:
#  \[
#  \widehat{\beta} =\XtWXinv\X^{\top}\W\y
#  \]

