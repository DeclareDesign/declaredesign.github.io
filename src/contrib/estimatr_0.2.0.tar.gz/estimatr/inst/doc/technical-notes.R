## ---- echo = FALSE-------------------------------------------------------
set.seed(42)
knitr::opts_chunk$set(
  collapse = TRUE, 
  comment = "#>"
)
options(digits = 2)

