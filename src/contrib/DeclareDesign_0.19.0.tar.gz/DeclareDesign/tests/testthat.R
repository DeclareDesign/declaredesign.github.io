library(testthat)
library(DeclareDesign)

test_check("DeclareDesign")
