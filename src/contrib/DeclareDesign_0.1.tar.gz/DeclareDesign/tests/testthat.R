library(testthat)
library(DeclareDesign)
library(magrittr)

test_check("DeclareDesign")
