

#' Declare Assignment Procedure
#'
#' @param ... Arguments to the assignment function.
#' @param handler A function that takes a data.frame, adds an assignment variable and optionally assignment probabilities or other relevant quantities, and returns a data.frame. By default, the assignment_function uses the \link{randomizr} functions \code{\link{conduct_ra}} and \code{\link{obtain_condition_probabilities}} to conduct random assignment and obtain the probabilities of assignment to each condition.
#'
#' @return a function that takes a data.frame as an argument and returns a data.frame with additional columns appended including an assignment variable and (optionally) probabilities of assignment.
#' @export
#'
#' @details
#'
#' While declare_assignment can work with any assignment_function that takes data and returns data, most random assignment procedures can be easily implemented with randomizr. The arguments to \code{\link{conduct_ra}} can include N, block_var, clust_var, m, m_each, prob, prob_each, block_m, block_m_each = NULL, block_prob, block_prob_each, num_arms, and condition_names. The arguments you need to specify are different for different designs. Check the help files for \code{\link{complete_ra}}, \code{\link{block_ra}}, \code{\link{cluster_ra}}, or \code{\link{block_and_cluster_ra}} for details on how to execute many common designs.
#'
#' @importFrom rlang quos quo lang_modify eval_tidy !!!
#' @importFrom randomizr declare_ra
#'
#' @examples
#'
#' my_population <- declare_population(N = 100, female = rbinom(N, 1, .5))
#' df <- my_population()
#'
#' # Complete random assignment using randomizr
#' # use any arguments you would use in conduct_ra.
#'
#' my_assignment <- declare_assignment(m = 50)
#' df <- my_assignment(df)
#' head(df)
#' table(df$Z)
#'
#' # Block random assignment
#'
#' my_blocked_assignment <- declare_assignment(blocks = female)
#'
#' df <- my_population()
#'
#' df <- my_blocked_assignment(df)
#' head(df)
#' with(df, table(Z, female))
#'
#'
#' # Custom random assignment functions
#'
#' df <- my_population()
#'
#' my_assignment_function <- function(data) {
#'    data$Z <- rbinom(n = nrow(data),
#'    size = 1,
#'    prob = 0.5)
#'    data
#'    }
#'
#' my_assignment_custom <- declare_assignment(
#'    handler = my_assignment_function)
#'
#' df <- my_assignment_custom(df)
#' head(df)
#' table(df$Z)
declare_assignment <- make_declarations(assignment_function_default, "assignment" )

# declare_assignment <-
#   function(..., assignment_function = assignment_function_default) {
#     args <- eval(substitute(alist(...)))
#     env <- freeze_environment(parent.frame())
#     func <- eval(assignment_function)
#
#     if (!("data" %in% names(formals(func)))) {
#       stop("Please choose an assignment_function with a data argument.")
#     }
#
#     assignment_function_internal <- function(data) {
#       args$data <- data
#       do.call(func, args = args, envir = env)
#     }
#
#     attributes(assignment_function_internal) <-
#       list(call = match.call(), type = "assignment")
#
#     if (from_package(assignment_function, "DeclareDesign") &
#         substitute(assignment_function) == "assignment_function_default") {
#       args_randomizr <- quos(...)
#
#       if (any(names(args_randomizr) == "assignment_variable_name")) {
#         args_randomizr$assignment_variable_name <- NULL
#       }
#       randomizr_call <- quo(declare_ra(!!! args_randomizr))
#
#       randomizr_summary <- function(data) {
#         randomizr_call <- lang_modify(randomizr_call, N = nrow(data))
#         return(print(eval_tidy(randomizr_call, data = data)))
#       }
#
#       attributes(assignment_function_internal)$summary_function <-
#         randomizr_summary
#
#     }
#
#     return(assignment_function_internal)
#   }

#' @importFrom rlang quos !!! lang_modify eval_tidy quo f_rhs
#' @importFrom randomizr conduct_ra obtain_condition_probabilities
assignment_function_default <-
  function(data, ..., assignment_variable_name = Z) {
    ## draw assignment

    options <- quos(...)

    if (any(names(options) %in% c("block_var"))) {
      if (class(f_rhs(options[["block_var"]])) == "character") {
        stop("Please provide the bare (unquoted) block variable name to block_var.")
      }
    }
    if (any(names(options) %in% c("clust_var"))) {
      if (class(f_rhs(options[["clust_var"]])) == "character") {
        stop("Please provide the bare (unquoted) cluster variable name to clust_var.")
      }
    }

    assignment_variable_name <- substitute(assignment_variable_name)
    if (!is.null(assignment_variable_name)) {
      assignment_variable_name <- as.character(assignment_variable_name)
    } else {
      stop("Please provide a name for the assignment variable as assignment_variable_name.")
    }

    ra_call <- quo(conduct_ra(!!! options))
    ra_call <- lang_modify(ra_call, N = nrow(data))

    data[, assignment_variable_name] <- eval_tidy(ra_call, data = data)

    ## obtain condition probabilities

    prob_call <- quo(obtain_condition_probabilities(!!! options))
    prob_call <- lang_modify(prob_call, assignment = data[, assignment_variable_name])

    data[, paste0(assignment_variable_name, "_cond_prob")] <-
      eval_tidy(prob_call, data = data)

    return(data)

  }
