## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ----echo=TRUE, results="hide"-------------------------------------------
variable_data <-
  fabricate(
    cities = level(N = 2, elevation = runif(n = N, min = 1000, max = 2000)),
    citizens = level(N = c(2, 4), age = runif(N, 18, 70))
  )
variable_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(variable_data)

## ----echo=TRUE, results="hide"-------------------------------------------
my_data <-
  fabricate(
    cities = level(N = 2, elevation = runif(n = N, min = 1000, max = 2000)),
    citizens = level(N = sample(1:6, size = 2, replace = TRUE), 
                     age = runif(N, 18, 70))
  )
my_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(my_data)

## ----echo=TRUE, results="hide"-------------------------------------------
variable_n_function = fabricate(
  cities = level(N = 5, population = runif(N, 10, 200)),
  citizens = level(N = round(population * 0.3))
)
head(variable_n_function)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(head(variable_n_function))

## ----echo=TRUE, results="hide"-------------------------------------------
ave_example = fabricate(
    cities = level(N = 2),
    citizens = level(N = 1:2, 
                     income = rnorm(N), 
                     income_mean_city = ave(income, cities))
    ) 
ave_example

## ----echo=FALSE----------------------------------------------------------
knitr::kable(ave_example)

## ---- message=FALSE, echo=TRUE, results="hide"---------------------------
library(dplyr)

# letting higher levels depend on lower levels

my_data <- 
fabricate(
    cities = level(N = 2, elevation = runif(n = N, min = 1000, max = 2000)),
    citizens = level(N = c(2, 3), age = runif(N, 18, 70))
  ) %>%
  group_by(cities) %>%
  mutate(pop = n())

my_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(my_data)

## ----echo=TRUE, results="hide"-------------------------------------------
my_data <- 
data_frame(Y = sample(1:10, 2)) %>%
  fabricate(lower_level = level(N = 3, Y2 = Y + rnorm(N)))
my_data

## ----echo=FALSE----------------------------------------------------------
knitr::kable(my_data)

