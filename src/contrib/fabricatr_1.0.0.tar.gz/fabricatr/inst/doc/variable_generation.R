## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ------------------------------------------------------------------------
draw_discrete_ex = fabricate(N = 3, p = c(0, .5, 1), 
                             binary_1 = draw_discrete(x = p),
                             binary_2 = draw_discrete(N = 3, x = 0.5))

## ------------------------------------------------------------------------
binary_alias_ex = fabricate(N = 3, 
                            binary_1 = draw_discrete(N = N, x = 0.5, type="binary"),
                            binary_2 = draw_discrete(N = N, x = 0.5, type="bernoulli"),
                            binary_3 = draw_discrete(N = N, x = 0.5, type="binomial"),
                            binary_4 = draw_binary(N = N, x = 0.5)
)

## ------------------------------------------------------------------------
binomial_ex = fabricate(N = 3, 
                        freethrows = draw_discrete(N = N, 
                                                   x = 0.5, 
                                                   k = 10, 
                                                   type = "binomial")
                        )

## ------------------------------------------------------------------------
bernoulli_probit = fabricate(N = 3, x = 10*rnorm(N), 
                             binary = draw_discrete(x = x, 
                                                    type = "bernoulli", 
                                                    link = "probit"))

## ------------------------------------------------------------------------
ordered_example = fabricate(N = 3, 
                            x = 5 * rnorm(N), 
                            ordered = draw_discrete(x, 
                                                    type = "ordered", 
                                                    breaks = c(-Inf, -1, 1, Inf)
                                                    )
                            )

## ------------------------------------------------------------------------
ordered_probit_example = fabricate(N = 3, 
                                   x = 5 * rnorm(N), 
                                   ordered = draw_discrete(x, 
                                                           type = "ordered", 
                                                           breaks = c(-Inf, -1, 1, Inf), 
                                                           link = "probit"
                                                           )
                                   )

## ------------------------------------------------------------------------
count_outcome_example = fabricate(N = 3, 
                                  x = c(0, 5, 100), 
                                  count = draw_discrete(x, type = "count"))

## ------------------------------------------------------------------------
categorical_example = fabricate(N = 6, 
                                p1 = runif(N, 0, 1),
                                p2 = runif(N, 0, 1),
                                p3 = runif(N, 0, 1),
                                cat = draw_discrete(N = N, 
                                                    x = cbind(p1, p2, p3), 
                                                    type = "categorical")
                                )

## ------------------------------------------------------------------------
warn_draw_discrete_example = fabricate(N = 6, 
                                       cat = draw_discrete(N = N, 
                                                           x = c(0.2, 0.4, 0.4), 
                                                           type = "categorical")
                                       )

