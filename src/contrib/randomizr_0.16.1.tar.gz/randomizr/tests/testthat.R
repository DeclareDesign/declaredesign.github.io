library(testthat)
library(randomizr)

test_check("randomizr")
