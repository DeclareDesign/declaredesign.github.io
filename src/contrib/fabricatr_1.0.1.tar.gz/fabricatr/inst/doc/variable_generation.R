## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ------------------------------------------------------------------------
draw_discrete_ex = fabricate(N = 3, p = c(0, .5, 1), 
                             binary_1 = draw_discrete(x = p),
                             binary_2 = draw_discrete(N = 3, x = 0.5))

## ------------------------------------------------------------------------
binary_alias_ex = fabricate(N = 3, 
                            binary_1 = draw_discrete(N = N, x = 0.5, type="binary"),
                            binary_2 = draw_discrete(N = N, x = 0.5, type="bernoulli"),
                            binary_3 = draw_discrete(N = N, x = 0.5, type="binomial"),
                            binary_4 = draw_binary(N = N, x = 0.5)
)

## ------------------------------------------------------------------------
binomial_ex = fabricate(N = 3, 
                        freethrows = draw_discrete(N = N, 
                                                   x = 0.5, 
                                                   k = 10, 
                                                   type = "binomial")
                        )

## ------------------------------------------------------------------------
bernoulli_probit = fabricate(N = 3, x = 10*rnorm(N), 
                             binary = draw_discrete(x = x, 
                                                    type = "bernoulli", 
                                                    link = "probit"))

## ------------------------------------------------------------------------
ordered_example = fabricate(N = 3, 
                            x = 5 * rnorm(N), 
                            ordered = draw_discrete(x, 
                                                    type = "ordered", 
                                                    breaks = c(-Inf, -1, 1, Inf)
                                                    )
                            )

## ------------------------------------------------------------------------
ordered_probit_example = fabricate(N = 3, 
                                   x = 5 * rnorm(N), 
                                   ordered = draw_discrete(x, 
                                                           type = "ordered", 
                                                           breaks = c(-Inf, -1, 1, Inf), 
                                                           link = "probit"
                                                           )
                                   )

## ------------------------------------------------------------------------
count_outcome_example = fabricate(N = 3, 
                                  x = c(0, 5, 100), 
                                  count = draw_discrete(x, type = "count"))

## ------------------------------------------------------------------------
categorical_example = fabricate(N = 6, 
                                p1 = runif(N, 0, 1),
                                p2 = runif(N, 0, 1),
                                p3 = runif(N, 0, 1),
                                cat = draw_discrete(N = N, 
                                                    x = cbind(p1, p2, p3), 
                                                    type = "categorical")
                                )

## ------------------------------------------------------------------------
warn_draw_discrete_example = fabricate(N = 6, 
                                       cat = draw_discrete(N = N, 
                                                           x = c(0.2, 0.4, 0.4), 
                                                           type = "categorical")
                                       )

## ----echo=FALSE----------------------------------------------------------
set.seed(19861108)

## ----echo=TRUE, results="hide"-------------------------------------------
# 100 individual population, 10 each in each of 10 clusters
clusters = rep(1:10, 10)

# Individuals have a 20% chance of smoking, but clusters are highly correlated
# in their tendency to smoke
smoker = draw_binary_icc(x = 0.2,
                         clusters = clusters,
                         rho = 0.7)

# Observe distribution of smokers and non-smokers
table(smoker)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(as.matrix(t(table(smoker))))

## ----echo=TRUE, results="hide"-------------------------------------------
table(clusters, smoker)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(clusters, smoker))

## ----echo=FALSE----------------------------------------------------------
set.seed(19861108)

## ----echo=TRUE, results="hide"-------------------------------------------
# 100 students, 10 each in 10 clusters
clusters = rep(1:10, 10)

numeric_grade = draw_normal_icc(x = 80,
                               clusters = clusters,
                               rho = 0.5,
                               sd = 15)

letter_grade = draw_discrete(x = numeric_grade,
                             type = "ordered",
                             breaks = c(-Inf, 60, 70, 80, 90, Inf),
                             break_labels = c("F", "D", "C", "B", "A"))

mean(numeric_grade)

## ----echo=TRUE, results="hide"-------------------------------------------
table(letter_grade, clusters)

## ----echo=FALSE----------------------------------------------------------
knitr::kable(table(clusters, letter_grade))

