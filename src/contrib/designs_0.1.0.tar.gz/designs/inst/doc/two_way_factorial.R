## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(designs)

## ----args, code=template_default_args_text(two_way_factorial_template)----
N <- 30
beta_A <- 1
beta_B <- -1
beta_AB <- 0.5

## ----body, code=template_text(two_way_factorial_template)----------------
# Model ------------------------------------------------------------------------
population <- declare_population(N = N, noise = rnorm(N))

potential_outcomes <- declare_potential_outcomes(
  Y ~ beta_A*A + beta_B*B + beta_AB*A*B + noise,
  conditions=list(A=0:1, B=0:1)
)

# Inquiry ----------------------------------------------------------------------
estimand <- declare_estimand(
  interaction = mean((Y_A_1_B_1 - Y_A_1_B_0) - (Y_A_0_B_1 - Y_A_0_B_0))
  )

# Data Strategy ----------------------------------------------------------------
assignment <- declare_assignment(assignment_variable=A && B)

# Answer Strategy --------------------------------------------------------------
estimator <- declare_estimator(Y ~ A + B + A:B,
                               model = lm_robust,
                               coefficients = "A:B",
                               estimand = estimand)

# Design -----------------------------------------------------------------------
design <- declare_design(
  population,
  potential_outcomes,
  estimand,
  assignment,
  declare_reveal(Y, A && B),
  estimator)

## ----two_way_factorial_diagnosis-----------------------------------------
diagnosis <- diagnose_design(design, sims = 10000, bootstrap = 1000)

## ----echo = FALSE--------------------------------------------------------
if(exists("diagnosis")) {
  cols <- c("Mean Estimate"="mean_estimate",
           "Mean Estimand"="mean_estimand",
           "Bias"="bias",
           "SE(bias)"="se(bias)",
           "Power"="power",
           "SE(Power)"="se(power)",
           "Coverage"="coverage",
           "SE(Coverage)"="se(coverage)"
  )
  diagnosis_table <- get_diagnosands(diagnosis)[cols]
  diagnosands <- get_diagnosands(diagnosis)
  names(diagnosis_table) <- names(cols)
  
  mean_estimate <- round(diagnosands[1,"mean_estimate"],3)
  mean_estimand <- round(diagnosands[1,"mean_estimand"],3)
  bias <- round(diagnosands[1,"bias"],3)
  power <- round(diagnosands[1,"power"],2)*100
  coverage <- round(diagnosands[1,"coverage"],2)*100
  
  knitr::kable(diagnosis_table,digits = 3)
}

## ------------------------------------------------------------------------
#The first thing to note about the design is that it produces an unbiased estimate of the quantity we care about: the average estimate is equal to the average estimand, at `r get0("mean_estimate", ifnotfound=NA)`. The design exhibits good coverage too, with the estimand falling within the estimated confidence intervals roughly `r get0("coverage", ifnotfound=NA)`% of the time.
  
#Note, however, that the power of this design is very low. Even with 1000 subjects, at `r get0("power", ifnotfound=NA)`% power, whether or not we detect the reasonably large one-quarter standard deviation effect is essentially a coin toss. Half of the time we run the risk of erroneously maintaining a null of no effect, whereas in combination the treatments do in fact produce a fairly large effect.
  
#We can use the design template `two_way_factorial_template` to quickly declare an array of designs that increment the $N$ from 150 to 3,000 by increments of 150. Diagnosing and plotting the results of this exercise reveals that we would require over 2,000 respondents to reach statistical power at the conventional 80% level.

## ----two_way_factorial_diagnoses_N---------------------------------------
designs <- expand_design(two_way_factorial_template,
                        N = seq(150,3000,150),  
                        beta_A = 0,
                        beta_B = 0,
                        beta_AB = .25)
diagnoses_N <- diagnose_design(designs, sims = 1000, bootstrap = FALSE)

## ---- echo = FALSE-------------------------------------------------------
if(exists("diagnoses_N")) {
diagnosands_N <- get_diagnosands(diagnoses_N) 
min_sample <- min(diagnosands_N$N[diagnosands_N$power>.8])
ggplot(diagnosands_N,
	aes(
		y = power, 
		x = N
	)
) +
geom_point(color = "#C67800") +
geom_smooth(se = FALSE, size = .5, color = "#205C8A", method = "loess") +
scale_y_continuous(name = "Power",limits = c(0,1.1),breaks = c(seq(0,1,.25),.8),minor_breaks = NULL) +
scale_x_continuous(name = "N",breaks = c(500,1000,1500,2000,min_sample,2500,3000), 
labels =  c(500,1000,1500,2000,paste0("\n",min_sample),2500,3000)
) + 
geom_hline(yintercept = .8,size = .1) +
geom_vline(xintercept = min_sample,size = .1) +
   theme_bw() +
      theme(
        axis.ticks = element_blank(),
        axis.line = element_blank(),
        panel.border = element_blank(),
        panel.grid.major = element_line(color = '#eeeeee'),
        strip.background = element_blank(),
        legend.position = "bottom",
        text = element_text(family = "Helvetica")
        )
}

