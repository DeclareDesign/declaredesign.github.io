## ----MIDA, echo = FALSE,include = FALSE----------------------------------
library(designs)




## ----args, code=template_default_args_text(two_arm_template)-------------
N <- 500
prob <- 0.5
tau_mean <- 1
tau_sd <- 3
outcome_sd <- 3

## ----body, code=template_text(two_arm_template)--------------------------
population <- declare_population(
  N = N,
  noise = rnorm(N, sd = outcome_sd),
  treatment_effect = rnorm(N, mean = tau_mean, sd = tau_sd)
)
potential_outcomes <- declare_potential_outcomes(Y ~ Z * treatment_effect + noise)
assignment <- declare_assignment(prob = prob)
estimand <- declare_estimand(ATE = mean(Y_Z_1 - Y_Z_0))
estimator <- declare_estimator(Y ~ Z, estimand = estimand)
two_arm <- declare_design(population,
                          potential_outcomes,
                          estimand,
                          assignment,
                          estimator)

## ----two_arm_diagnosis---------------------------------------------------
diagnosis <- diagnose_design(two_arm, sims = 10000, bootstrap = 1000)

## ----echo = FALSE--------------------------------------------------------
if(exists("diagnosis")) {
  diagnosands <- get_diagnosands(diagnosis)
  diagnosis_table <- diagnosands[,c("mean_estimate","mean_estimand","bias","se(bias)","power","se(power)","coverage","se(coverage)")]
  names(diagnosis_table) <- c("Mean Estimate", "Mean Estimand", "Bias", "SE(Bias)", "Power", "SE(Power)", "Coverage", "SE(Coverage)")
  
  mean_estimate <- round(diagnosands[1,"mean_estimate"],3)
  mean_estimand <- round(diagnosands[1,"mean_estimand"],3)
  bias <- round(diagnosands[1,"bias"],3)
  power <- round(diagnosands[1,"power"],2)*100
  coverage <- round(diagnosands[1,"coverage"],2)*100
  
  knitr::kable(diagnosis_table,digits = 3)
} else {
  mean_estimate <- mean_estimand <- bias <- power <- coverage<- NA
}


