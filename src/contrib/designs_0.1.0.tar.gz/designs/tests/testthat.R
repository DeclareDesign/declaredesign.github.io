library(testthat)
library(designs)

test_check("designs")
