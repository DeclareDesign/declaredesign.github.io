## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ----eval=FALSE----------------------------------------------------------
#  library(wakefield)
#  
#  survey_experiment_df <- fabricate(
#    N = 50,
#    treatment = draw_binary(prob = 0.5, N = N),
#    age = age(n = N),
#    race = race(n = N),
#    sex = sex(n = N),
#  )

## ----eval=FALSE----------------------------------------------------------
#  survey_experiment_df <- r_data_frame(
#    n = 50,
#    age,
#    race,
#    sex)
#  
#  fabricatr_df <- fabricate(
#    data = survey_experiment_df,
#    treatment = draw_binary(prob = 0.5, N = N)
#  )

## ----eval=FALSE----------------------------------------------------------
#  library(randomNames)
#  
#  experiment_data <- fabricate(
#    N = 50,
#    treatment = draw_binary(prob = 0.5, N = N),
#    is_female = draw_binary(prob = 0.5, N = N),
#    patient_name = randomNames(N, gender=is_female)
#  )

## ----eval=FALSE----------------------------------------------------------
#  library("simcausal")
#  
#  # Define DAG
#  D <- DAG.empty() +
#    node("wealth", distr = "rnorm",
#         mean = 30000,
#         sd = 10000) +
#    node("schoolquality", distr = "runif",
#         min = 0 + (5 * (wealth > 50000)),
#         max = 10) +
#    node("testoutcome", distr = "runif",
#         min = 0 + 0.0001 * wealth + 0.25 * schoolquality,
#         max = 10)
#  
#  # Freeze DAG object
#  set_dag <- set.DAG(D)
#  
#  # Draw data from DAG
#  df <- sim(set_dag, n = 100)
#  
#  # Pass into fabricate call and make new variables as necessary
#  fabricate(df,
#            passed_test = testoutcome > 6,
#            eligible_for_snap = wealth < 25000)

## ----eval=FALSE----------------------------------------------------------
#  library(simsurv)
#  
#  # Simulate patient data in a clinical trial
#  participant_data <- fabricate(
#    N = 100,
#    age = runif(N, min = 18, max = 85),
#    is_female = draw_binary(prob = 0.5, N = N),
#    is_smoker = draw_binary(prob = 0.2 + 0.2 * (age > 50), N = N),
#    disease_stage = round(runif(N, min = 1 + 0.5 * (age > 65), max = 4)),
#    treatment = draw_binary(prob = 0.5, N = N),
#    kps = runif(N, min = 40, max = 100)
#  )
#  
#  # Simulate data in the survival context
#  survival_data <- simsurv(
#    lambdas = 0.1, gammas = 0.5,
#    x = participant_data,
#    betas = c(is_female = -0.2, is_smoker = 1.2,
#              treatment = -0.4, kps = -0.005,
#              disease_stage = 0.2),
#    maxt = 5)

## ----eval=FALSE----------------------------------------------------------
#  library(forecast)
#  
#  arima_model <- simulate(
#    Arima(ts(rnorm(100), frequency = 4),
#          order = c(1, 0, 1))
#  
#  fabricate(data.frame(arima_model),
#            year = rep(1:25, each=4),
#            quarter = rep(1:4, 25))

