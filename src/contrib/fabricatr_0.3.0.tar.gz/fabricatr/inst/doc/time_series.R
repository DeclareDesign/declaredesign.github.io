## ---- echo=FALSE---------------------------------------------------------
options(digits=2)
set.seed(19861108)
library(fabricatr)

## ----results="hide"------------------------------------------------------
panel_unit <- fabricate(
  N = 20,
  ts_year = 0:19,
  gdp_measure = 20 + 0.3 * ts_year + rnorm(N, sd=0.3)
)

## ----results="hide"------------------------------------------------------
panel_units <- fabricate(
  countries = add_level(
    N = 5,
    base_gdp = runif(N, 15, 22),
    growth_units = runif(N, 0.2, 0.8),
    growth_error = runif(N, 0.1, 0.5)
  ),
  years = add_level(
    N = 5,
    ts_year = 0:4,
    gdp_measure = base_gdp + (ts_year * growth_units) + rnorm(N, sd=growth_error)
  )
)

## ----results="hide"------------------------------------------------------
global_trend <- 0.1

global_trend_example <- fabricate(
  countries = add_level(
    N = 5,
    base_gdp = runif(N, 15, 22),
    growth_units = runif(N, 0.2, 0.8),
    growth_error = runif(N, 0.1, 0.5)
  ),
  years = add_level(
    N = 5,
    ts_year = 0:4,
    gdp_measure = base_gdp + 
      (ts_year * global_trend) + (ts_year * growth_units) + 
      rnorm(N, sd=growth_error)
  )
)

## ----results="hide"------------------------------------------------------
panel_global_data <- fabricate(
  years = add_level(
    N = 5,
    ts_year = 0:4,
    year_shock = rnorm(N, 0, 0.3)
  ),
  countries = add_level(
    N = 5,
    base_gdp = runif(N, 15, 22),
    growth_units = runif(N, 0.2, 0.5),
    growth_error = runif(N, 0.1, 0.5),
    nest = FALSE
  ),
  country_years = cross_levels(
    by = join(years, countries),
    gdp_measure = base_gdp + year_shock + (ts_year * growth_units) +
      rnorm(N, sd=growth_error)
  )
)

