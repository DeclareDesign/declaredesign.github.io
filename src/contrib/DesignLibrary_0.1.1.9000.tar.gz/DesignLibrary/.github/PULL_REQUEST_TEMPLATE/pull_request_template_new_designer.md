# Description

Please include a summary of the designer here.

# Checklist:

- [ ] Designer is documented according to the [contributing guidelines](https://declaredesign.org/library/articles/how_to_write_and_contribute_designers.html) 
- [ ] Designer and any vignettes have been added to overview.csv
- [ ] Tests added to testthat to ensure coverage remains at 100%
- [ ] Branch is passing devtools::check() with 0 errors, warnings, or notes



