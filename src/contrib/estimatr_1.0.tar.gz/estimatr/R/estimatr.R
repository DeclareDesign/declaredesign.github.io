#' estimatr package
#'
#' Some stuff about what this package is
#'
#' @docType package
#' @useDynLib estimatr
#' @importFrom Rcpp evalCpp
#' @importFrom stats sd var model.matrix.default pt qt var weighted.mean lm vcov
#' @name estimatr
NULL


