# estimatr 0.3.0 (GitHub version)

* Changed suffix added to centered variables in `lm_lin()` from `_bar` to `_c`
* Updated vignettes, including fixing math notation in vignettes for CRAN

# estimatr 0.2.0 (CRAN version)

* First **CRAN** upload
