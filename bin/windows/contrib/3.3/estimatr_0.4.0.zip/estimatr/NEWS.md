# estimatr 0.4.0 (GitHub version)

* Changed suffix added to centered variables in `lm_lin()` from `_bar` to `_c`
* Added all vignettes to `.Rbuildignore`, only available on website now
* Fixed `lm_robust_helper.cpp` algorithm to not catch own exception and to deal with `valgrind` memory errors
* Simplified some tests for various CRAN test platforms

# estimatr 0.2.0 (CRAN version)

* First **CRAN** upload
